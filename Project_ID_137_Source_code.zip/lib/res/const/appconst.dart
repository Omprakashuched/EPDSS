const String NOTIFICATION_CHANNEL_ID = 'Fahad Tech';
const String NOTIFICATION_CHANNEL_NAME = 'Foreground Services';
const String NOTIFICATION_TITLE = 'AWESOME SERVICE';
const String NOTIFICATION_CONTENT = 'Initializing';
const int FOREGROUND_SERVICE_NOTIFICATION_ID = 12;

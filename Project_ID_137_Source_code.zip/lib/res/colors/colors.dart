import 'package:flutter/material.dart';

Color white = Colors.white;
Color black = Colors.black;
List<Color> gradien = const [
  Color(0xFFFD8080),
  Color(0xFFFB8580),
  Color(0xFFFBD079),
];

Color primaryColor = const Color(0xfffc3b77);
Color policePrimary = const Color.fromARGB(255, 15, 0, 125);

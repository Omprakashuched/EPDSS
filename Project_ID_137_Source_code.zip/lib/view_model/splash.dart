import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:epdss/res/const/firebase_const.dart';
import 'package:epdss/views/child/home/home_screen.dart';
import 'package:epdss/views/child/auth/login_screen.dart';
import 'package:epdss/views/parents/parent_home_screen.dart';
import 'package:epdss/views/police/police_dashboard.dart';

class SplashScreenMethod {
  void startTimer(BuildContext context) {
    Timer(const Duration(seconds: 2), () async {
      if (auth.currentUser == null) {
        Get.off(() => const LoginScreen());
      } else {
        firestore
            .collection('users')
            .doc(auth.currentUser!.uid)
            .get()
            .then((value) {
          if (value['type'] == 'parent') {
            Get.off(() => const ParentHomeScreen());
          } else if (value['type'] == 'police') {
            Get.off(() => const PoliceDashboard());
          } else {
            Get.off(() => const HomeScreen());
          }
        });
      }
    });
  }
}

import 'package:get/get.dart';

class DistressScreenController extends GetxController {
  RxBool isLoading = false.obs;
}

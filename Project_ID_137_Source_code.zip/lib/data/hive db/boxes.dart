import 'package:hive/hive.dart';
import 'package:epdss/model/contact_model.dart';

class Boxes {
  static Box<ContactModel> getContacts() =>
      Hive.box<ContactModel>('contactsData');
}

package com.example.women_safety_app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.women_safety_app.R
import com.example.women_safety_app.MainActivity
import android.widget.Toast
import android.util.Log
class MyAppWidgetProvider : AppWidgetProvider() {


    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)

        for (appWidgetId in appWidgetIds) {
            Log.d("MyAppWidgetProvider", "Updating widget with ID: $appWidgetId")

            // Create an Intent to launch MainActivity (or DistressScreen if you want to open that)
            val intent = Intent(context, MainActivity::class.java) // Change this to your desired activity
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            // Create a PendingIntent with the intent to launch the activity when clicked
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Get the layout for the widget and attach an onClick listener
            val views = RemoteViews(context.packageName, R.layout.widget_layout)
            views.setOnClickPendingIntent(R.id.distress_button, pendingIntent)

            // Tell the AppWidgetManager to perform an update on the current app widget
            appWidgetManager.updateAppWidget(appWidgetId, views)

            Log.d("MyAppWidgetProvider", "Widget updated successfully")
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        Log.d("MyAppWidgetProvider", "Widget clicked!")
        // Check if this is the distress button click
        if (intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE) {
            Toast.makeText(context, "Widget clicked", Toast.LENGTH_SHORT).show()
        }
    }

  /*  override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // Perform this loop for each App Widget
        for (appWidgetId in appWidgetIds) {
            Log.d("MyAppWidgetProvider", "Updating widget with ID: $appWidgetId")
            // Create an intent to launch the Flutter app's MainActivity
            val intent = Intent(context, MainActivity::class.java)
            intent.action = "OPEN_DISTRESS_SCREEN"
            val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            // Get the layout for the App Widget and attach an on-click listener to the button
            val views = RemoteViews(context.packageName, R.layout.widget_layout)
            views.setOnClickPendingIntent(R.id.distress_button, pendingIntent)

            // Tell the AppWidgetManager to update the current widget
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }*/
}
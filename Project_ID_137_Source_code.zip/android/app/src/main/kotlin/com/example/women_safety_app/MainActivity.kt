package com.example.women_safety_app
import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if the intent has the action to open the DistressScreen
        val action = intent.action
        if (action == "OPEN_DISTRESS_SCREEN") {
            // Open DistressScreen using a Flutter route
            val flutterIntent = Intent(this, MainActivity::class.java)
            flutterIntent.putExtra("openDistressScreen", true)
            startActivity(flutterIntent)
        }
    }
}
